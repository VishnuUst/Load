Action()
{

	/* Login */

	web_add_auto_header("Accept-Language", 
		"en-GB,en;q=0.5");

	lr_think_time(44);

	

/*Correlation comment - Do not change!  Original value='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NWM5Y2IyN2QzNzc3NDAwMTM3M2YxMGMiLCJpYXQiOjE3MDg3NTY1ODd9.PiiDAtHJf5Nf6utUbcjbkjJ8R0qFzUvUG_CWokpZgI0' Name ='CorrelationParameter' Type ='Manual'*/
	

/*Correlation comment - Do not change!  Original value='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NWM5Y2IyN2QzNzc3NDAwMTM3M2YxMGMiLCJpYXQiOjE3MDg3NTY1ODd9.PiiDAtHJf5Nf6utUbcjbkjJ8R0qFzUvUG_CWokpZgI0' Name ='CorrelationParameter' Type ='Manual'*/
	/*web_reg_save_param_json(
		"ParamName=CorrelationParameter",
		"QueryString=$.token",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);*/

/*Correlation comment - Do not change!  Original value='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NWM5Y2IyN2QzNzc3NDAwMTM3M2YxMGMiLCJpYXQiOjE3MDg3NTY1ODd9.PiiDAtHJf5Nf6utUbcjbkjJ8R0qFzUvUG_CWokpZgI0' Name ='CorrelationParameter' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=paramToken",
		"QueryString=$.token",
		"SelectAll=No",
		SEARCH_FILTERS,
		"Scope=BODY",
		LAST);

	web_custom_request("login", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"vishnu1998thulasi@gmail.com\",\"password\":\"12345678\"}", 
		LAST);

	web_reg_find("Text=Click on any contact to view the Contact Details", 
		LAST);

	web_add_auto_header("Authorization","Bearer {paramToken}");
	web_url("contactList", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts", 
		"URL=https://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}
